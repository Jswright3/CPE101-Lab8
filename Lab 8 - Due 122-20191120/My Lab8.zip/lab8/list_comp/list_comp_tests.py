import unittest
from list_comp import *
from objects import *

class TestCases(unittest.TestCase):
"""
   def test_distance_all(self):
      list = []
      x = 0
      y = 0
      for i in range(3):
         x += 3
         y += 2
         list.append[Point(x,y)]
      self.assertEqual(distance_all(list),[])
"""
   def are_in_first_quadrant(list):



# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

